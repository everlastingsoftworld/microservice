﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomerService.Models;
using Microsoft.EntityFrameworkCore;
namespace CustomerService.Contexts
{
    public class CustomerContext:DbContext

    {
        public CustomerContext(DbContextOptions<CustomerContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Address> Addresses { get; set; }
      
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>()
       .HasMany(c => c.AddressList);      



        }

    }
}
