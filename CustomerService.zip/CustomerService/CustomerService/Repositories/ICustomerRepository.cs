﻿using CustomerService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.Repositories
{
    public interface ICustomerRepository
    {
        //CRUD operation
        Customer AddCustomer(Customer Customer);
        IEnumerable<Customer> GetAllCustomers();
        Customer GetCustomerById(long CustomerId);

        bool DeleteCustomerById(long CustomerId);
        Customer UpdateCustomer(Customer Customer);

    }
}
