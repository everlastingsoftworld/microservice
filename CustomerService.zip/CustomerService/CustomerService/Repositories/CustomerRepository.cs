﻿using CustomerService.Contexts;
using CustomerService.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.Repositories
{

    public class CustomerRepository : ICustomerRepository
    {

        private CustomerContext _dbContext;

        public CustomerRepository(CustomerContext dbContext)
        {
            this._dbContext = dbContext;
        }

        public Customer AddCustomer(Customer customer)
        {

            this._dbContext.Add(customer);
            Save();
            return customer;

        }

        public bool DeleteCustomerById(long CustomerId)
        {

            bool status = false;
            var customer = _dbContext.Customers.Find(CustomerId);
            _dbContext.Customers.Remove(customer);
            Save();
            if (GetCustomerById(CustomerId) == null)
                status = true;
            return status;

        }

        public IEnumerable<Customer> GetAllCustomers()
        {

            return this._dbContext.Customers.Include(c => c.AddressList)
                            
                .ToList();
        }

        public Customer GetCustomerById(long CustomerId)
        {
            var customer = _dbContext.Customers.Include(c => c.AddressList)

               .FirstOrDefault(x => x.CustomerId == CustomerId);
            return customer;

        }

        public Customer UpdateCustomer(Customer Customer)
        {
            _dbContext.Entry(Customer).State = EntityState.Modified;
            Save();
            return Customer;
        }

        public void Save()
        {
            _dbContext.SaveChanges();
        }

    }
}
