﻿using CustomerService.Repositories;
using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
/*
 * query($customerId:Long){
 customer(customerId:$customerId){
  firstName,
 
  customerId
}
}

query variable
{
  "customerId":2
}
 */
namespace CustomerService.GraphqlQueries
{
    public class CustomerGLQuery : ObjectGraphType
    {
        public CustomerGLQuery(ICustomerRepository CustomerRepository)
        {
            Name = "CustomerQuery";
            //get all customers
            Field<ListGraphType<CustomerGLType>>(
              "customers",
              resolve: context => CustomerRepository.GetAllCustomers()
          );

            //get customer by id
            Field<CustomerGLType>(
               "customer",
               arguments: new QueryArguments(new QueryArgument<LongGraphType> { Name = "CustomerId" }),
               resolve: context => CustomerRepository.GetCustomerById(context.GetArgument<long>("CustomerId"))

               );

        }
    }
}
