﻿using CustomerService.GraphqlQueries;
using CustomerService.Models;
using CustomerService.Repositories;
using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.GraphqlMutations
{
    public class CustomerGLMutation : ObjectGraphType
    {
        public CustomerGLMutation(ICustomerRepository repository)
        {
            //add customer
            Field<CustomerGLType>(
                "createCustomer",
                arguments: new QueryArguments(new QueryArgument<NonNullGraphType<CustomerGLInputType>>
                { Name = "customer" }),
                resolve: context =>
                {
                    var cust = context.GetArgument<Customer>("customer");
                    return repository.AddCustomer(cust);
                }
            );

            //delete customer
            Field<StringGraphType>(
                "deleteCustomer",
                arguments: new QueryArguments(new QueryArgument<NonNullGraphType<LongGraphType>>
                { Name = "customerId" }),
                resolve: context =>
                {
                    var custId = context.GetArgument<long>("customerId");
                    repository.DeleteCustomerById(custId);
                    return $"CustomerId {custId} is successfully deleted";
                }
            );

            // Field<CategoryType>(
            //    "updateCategory",
            //    arguments: new QueryArguments(new QueryArgument<NonNullGraphType<CategoryType>>
            //    { Name = "category" }),
            //    resolve: context =>
            //    {
            //        var category= context.GetArgument<Category>("category");
            //        return repository.UpdateCategoryById(category);

            //    }
            //);

        }
    }
}
