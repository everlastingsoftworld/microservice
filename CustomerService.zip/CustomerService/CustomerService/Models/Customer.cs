﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CustomerService.Models
{
    [Table("BOA_CUSTOMER")]
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("Customer_Id")]
        public long CustomerId { get; set; }
        public Name FullName { get; set; }
        public ICollection<Address> AddressList { get; set; }
    }
}
