﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.Models
{
    [Owned]
    public class Name
    {
        [Column("First_Name")]
        public String FirstName { get; set; }
        [Column("Middle_Name")]
        public String MiddleName { get; set; }
        [Column("Last_Name")]
        public String LastName { get; set; }
    }
}
