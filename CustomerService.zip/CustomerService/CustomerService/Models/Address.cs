﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.Models
{
    [Table("Address")]
    public class Address
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("Address_Id")]
        public long AddressId { get; set; }
        [Column("Street_Name")]
        public String StreetName { get; set; }
        [Column("Door_No")]
        public String DoorNo { get; set; }
        [Column("City")]
        public String City { get; set; }
        [Column("State")]
        public String State { get; set; }
        [ForeignKey("Customer")]
        [Column("CustomerId_Fk")]
        public long CustomerId { get; set; }
        public Customer Customer { get; set; }

    }
}
