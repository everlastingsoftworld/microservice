﻿using CustomerService.Models;
using CustomerService.Repositories;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;

namespace CustomerService.Controllers
{
    [ApiVersion("1")]
    [ApiVersion("2")]
    [Route("api/v{version:apiVersion}/[controller]")]
    // [Route("api/[controller]")]
    [ApiController]

    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository _CustomerRepository;

        public CustomerController(ICustomerRepository CustomerRepository)
        {
            _CustomerRepository = CustomerRepository;

        }

        // GET: api/Customer
        // [MapToApiVersion("1")]
        [Route("Customers")]
        [HttpGet]
        public IActionResult Get()
        {
            var customers = this._CustomerRepository.GetAllCustomers();
            return new OkObjectResult(customers);
        }


        // GET: api/Stock/5
        [HttpGet("{customerId}", Name = "Get")]
        public IActionResult Get(long customerId)
        {
            var customer = this._CustomerRepository.GetCustomerById(customerId);
            return new OkObjectResult(customer);
        }

        // POST: api/Employee
        [HttpPost]
        public IActionResult Post([FromBody] Customer Customer)
        {
            using (var scope = new TransactionScope())
            {
                _CustomerRepository.AddCustomer(Customer);
                scope.Complete();
                return CreatedAtAction(nameof(Get),
                    new { id = Customer.CustomerId }, Customer);
            }
        }

        // PUT: api/Stock/5
        [HttpPut("{customerId}")]
        public IActionResult Put(long customerId, [FromBody] Customer Customer)
        {
            if (Customer != null)
            {
                using (var scope = new TransactionScope())
                {
                    _CustomerRepository.UpdateCustomer(Customer);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{customerId}")]
        public IActionResult Delete(long customerId)
        {
            _CustomerRepository.DeleteCustomerById(customerId);
            return new OkResult();
        }

    }
}
