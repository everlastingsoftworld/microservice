﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.GraphqlMutations
{
    public class NameGLInputType : InputObjectGraphType
    {
        public NameGLInputType()
        {
            Name = "NameInput";
            Field<NonNullGraphType<StringGraphType>>("FirstName");
            Field<NonNullGraphType<StringGraphType>>("MiddleName");
            Field<NonNullGraphType<StringGraphType>>("LastName");
        }
    }
}
