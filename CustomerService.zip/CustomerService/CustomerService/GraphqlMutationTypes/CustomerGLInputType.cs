﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.GraphqlMutations
{
    public class CustomerGLInputType : InputObjectGraphType
    {
        public CustomerGLInputType()
        {
            Name = "CustomerInput";
            Field<NonNullGraphType<NameGLInputType>>("FullName");
           
        }
    }
}
