﻿using CustomerService.Models;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.GraphqlQueries
{
    public class AddressGLType:ObjectGraphType<Address>
    {
        public AddressGLType()
        {
            Name = "Address";
            Field(_ => _.AddressId).Description("AddressId");
            Field(_ => _.DoorNo).Description("DoorNo");
            Field(_ => _.StreetName).Description("StreetName");
            Field(_ => _.City).Description("City");
            Field(_ => _.State).Description("State");
            //Field(_ => _.Customer.CustomerId).Description("CustomerId");
            //Field(_ => _.Customer.FullName.FirstName).Description("FirstName");
            //Field(_ => _.Customer.FullName.MiddleName).Description("MiddleName");
            //Field(_ => _.Customer.FullName.LastName).Description("LastName");
        }
    }
}
