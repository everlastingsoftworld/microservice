﻿using CustomerService.Models;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerService.GraphqlQueries
{
    public class CustomerGLType:ObjectGraphType<Customer>
    {
        public CustomerGLType()
        {
            Name = "Customer";
            Field(_ => _.CustomerId).Description("CustomerId");
            Field(_ => _.FullName.FirstName).Description("FirstName");
            Field(_ => _.FullName.MiddleName).Description("MiddleName");
            Field(_ => _.FullName.LastName).Description("LastName");           
        }
    }
}
